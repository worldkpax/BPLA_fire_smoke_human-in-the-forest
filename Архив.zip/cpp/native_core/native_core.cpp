#include "native_core.hpp"

#include <cmath>
#include <stdexcept>

namespace {
constexpr double kEarthRadiusM = 6'371'000.0;  // meters
constexpr double kPi = 3.14159265358979323846;

inline double deg2rad(double deg) {
    return deg * kPi / 180.0;
}
}  // namespace

double geo_distance_m(double lat1_deg, double lon1_deg, double lat2_deg, double lon2_deg) {
    // Haversine great-circle distance.
    const double lat1 = deg2rad(lat1_deg);
    const double lat2 = deg2rad(lat2_deg);
    const double dlat = lat2 - lat1;
    const double dlon = deg2rad(lon2_deg - lon1_deg);

    const double a = std::sin(dlat / 2) * std::sin(dlat / 2) +
                     std::cos(lat1) * std::cos(lat2) * std::sin(dlon / 2) * std::sin(dlon / 2);
    const double c = 2 * std::asin(std::min(1.0, std::sqrt(a)));
    return kEarthRadiusM * c;
}

void geo_project_bbox_to_ground(
    double lat_deg, double lon_deg, double /*alt_m*/,
    double /*yaw_rad*/, double /*pitch_rad*/, double /*roll_rad*/,
    double /*fx*/, double /*fy*/, double /*cx*/, double /*cy*/,
    double x_min, double y_min, double x_max, double y_max,
    double* out_lat_center_deg,
    double* out_lon_center_deg) {
    // Simple placeholder: return UAV position; compute bbox center to allow future use.
    const double cx = (x_min + x_max) * 0.5;
    const double cy = (y_min + y_max) * 0.5;
    (void)cx;
    (void)cy;
    // TODO: replace with proper projection using camera intrinsics + attitude.
    if (out_lat_center_deg) {
        *out_lat_center_deg = lat_deg;
    }
    if (out_lon_center_deg) {
        *out_lon_center_deg = lon_deg;
    }
}

double route_length_m(const std::vector<double>& lats_deg,
                      const std::vector<double>& lons_deg,
                      const std::vector<double>& alts_m) {
    if (lats_deg.size() != lons_deg.size() || lats_deg.size() != alts_m.size()) {
        throw std::invalid_argument("route_length_m: vector sizes must match");
    }
    if (lats_deg.size() < 2) {
        return 0.0;
    }

    double total = 0.0;
    for (size_t i = 1; i < lats_deg.size(); ++i) {
        total += geo_distance_m(lats_deg[i - 1], lons_deg[i - 1], lats_deg[i], lons_deg[i]);
    }
    // Altitude change ignored in distance; acceptable for placeholder.
    return total;
}

double route_energy_cost(const std::vector<double>& lats_deg,
                         const std::vector<double>& lons_deg,
                         const std::vector<double>& alts_m,
                         double mass_kg,
                         double base_power_w) {
    if (lats_deg.size() != lons_deg.size() || lats_deg.size() != alts_m.size()) {
        throw std::invalid_argument("route_energy_cost: vector sizes must match");
    }
    const double length_m = route_length_m(lats_deg, lons_deg, alts_m);
    // Placeholder model; refine with aerodynamics/drag as needed.
    const double energy = length_m * mass_kg * base_power_w * 1e-3;
    return energy;
}
