#pragma once

#include <vector>

// Geodesic distance between two WGS84 points (degrees) using haversine, meters.
double geo_distance_m(double lat1_deg, double lon1_deg, double lat2_deg, double lon2_deg);

// Project bounding box center from image plane to ground lat/lon.
// Placeholder: assumes camera is nadir-aligned; returns UAV position for now.
void geo_project_bbox_to_ground(
    double lat_deg, double lon_deg, double alt_m,
    double yaw_rad, double pitch_rad, double roll_rad,
    double fx, double fy, double cx, double cy,
    double x_min, double y_min, double x_max, double y_max,
    double* out_lat_center_deg,
    double* out_lon_center_deg);

// Compute total route length (meters) given waypoint lat/lon/alt vectors.
// Throws std::invalid_argument if vector sizes mismatch. Altitude is currently ignored.
double route_length_m(const std::vector<double>& lats_deg,
                      const std::vector<double>& lons_deg,
                      const std::vector<double>& alts_m);

// Placeholder energy cost model for a route.
// Throws std::invalid_argument on size mismatch.
double route_energy_cost(const std::vector<double>& lats_deg,
                         const std::vector<double>& lons_deg,
                         const std::vector<double>& alts_m,
                         double mass_kg,
                         double base_power_w);

