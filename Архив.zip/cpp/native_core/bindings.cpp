#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

#include "native_core.hpp"

namespace py = pybind11;

PYBIND11_MODULE(native_core, m) {
    m.doc() = "Native performance helpers for geo projection and energy estimation";

    m.def(
        "geo_distance_m",
        &geo_distance_m,
        py::arg("lat1_deg"),
        py::arg("lon1_deg"),
        py::arg("lat2_deg"),
        py::arg("lon2_deg"),
        R"pbdoc(
Great-circle distance in meters between two WGS84 points (degrees).
)pbdoc");

    m.def(
        "geo_project_bbox_to_ground",
        [](double lat_deg, double lon_deg, double alt_m, double yaw_rad, double pitch_rad, double roll_rad,
           double fx, double fy, double cx, double cy, double x_min, double y_min, double x_max, double y_max) {
            double out_lat = 0.0;
            double out_lon = 0.0;
            geo_project_bbox_to_ground(lat_deg, lon_deg, alt_m, yaw_rad, pitch_rad, roll_rad, fx, fy, cx, cy, x_min,
                                       y_min, x_max, y_max, &out_lat, &out_lon);
            return py::make_tuple(out_lat, out_lon);
        },
        py::arg("lat_deg"),
        py::arg("lon_deg"),
        py::arg("alt_m"),
        py::arg("yaw_rad"),
        py::arg("pitch_rad"),
        py::arg("roll_rad"),
        py::arg("fx"),
        py::arg("fy"),
        py::arg("cx"),
        py::arg("cy"),
        py::arg("x_min"),
        py::arg("y_min"),
        py::arg("x_max"),
        py::arg("y_max"),
        R"pbdoc(
Project bounding box center from image plane to ground coordinates.

Placeholder implementation: returns UAV position for now.
)pbdoc");

    m.def(
        "route_length_m",
        [](const std::vector<double>& lats, const std::vector<double>& lons, const std::vector<double>& alts) {
            if (lats.size() != lons.size() || lats.size() != alts.size()) {
                throw py::value_error("route_length_m: vector sizes must match");
            }
            return route_length_m(lats, lons, alts);
        },
        py::arg("lats"),
        py::arg("lons"),
        py::arg("alts"),
        R"pbdoc(
Compute total route length (meters). Altitude is currently ignored.
)pbdoc");

    m.def(
        "route_energy_cost",
        [](const std::vector<double>& lats, const std::vector<double>& lons, const std::vector<double>& alts,
           double mass_kg, double base_power_w) {
            if (lats.size() != lons.size() || lats.size() != alts.size()) {
                throw py::value_error("route_energy_cost: vector sizes must match");
            }
            return route_energy_cost(lats, lons, alts, mass_kg, base_power_w);
        },
        py::arg("lats"),
        py::arg("lons"),
        py::arg("alts"),
        py::arg("mass_kg"),
        py::arg("base_power_w"),
        R"pbdoc(
Placeholder energy cost model proportional to distance, mass, and base power.
)pbdoc");
}

