from fire_uav.module_core.detections.pipeline import *  # noqa: F401,F403

