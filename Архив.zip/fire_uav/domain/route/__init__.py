from fire_uav.module_core.route import *  # noqa: F401,F403
