from fire_uav.module_core.route.energy import *  # noqa: F401,F403

