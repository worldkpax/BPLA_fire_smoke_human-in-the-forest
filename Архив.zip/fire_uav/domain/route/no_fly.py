from fire_uav.module_core.route.no_fly import *  # noqa: F401,F403

