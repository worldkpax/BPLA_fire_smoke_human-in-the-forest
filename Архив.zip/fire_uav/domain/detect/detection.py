from fire_uav.module_core.detect.detection import *  # noqa: F401,F403

