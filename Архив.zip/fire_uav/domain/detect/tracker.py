from fire_uav.module_core.detect.tracker import *  # noqa: F401,F403

