from fire_uav.module_core.fusion import *  # noqa: F401,F403
