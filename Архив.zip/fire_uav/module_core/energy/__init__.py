from fire_uav.module_core.energy.python_energy_model import PythonEnergyModel

__all__ = ["PythonEnergyModel"]
