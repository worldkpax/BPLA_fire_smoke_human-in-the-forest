from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Tuple, TYPE_CHECKING

if TYPE_CHECKING:
    from fire_uav.module_core.detections.pipeline import RawDetectionPayload


@dataclass
class SmoothedBBoxState:
    x_min: float
    y_min: float
    x_max: float
    y_max: float

    def as_tuple(self) -> tuple[float, float, float, float]:
        return self.x_min, self.y_min, self.x_max, self.y_max


class BBoxSmoother:
    def __init__(self, alpha: float = 0.5, max_center_distance_px: float = 80.0) -> None:
        self.alpha = alpha
        self.max_center_distance_px = max_center_distance_px
        self._tracks: Dict[int, SmoothedBBoxState] = {}
        self._next_track_id: int = 0

    def _center(self, bbox: tuple[float, float, float, float]) -> tuple[float, float]:
        x_min, y_min, x_max, y_max = bbox
        return (x_min + x_max) / 2.0, (y_min + y_max) / 2.0

    def _match_track(self, bbox: tuple[float, float, float, float]) -> int | None:
        cx, cy = self._center(bbox)
        best_id: int | None = None
        best_dist = float("inf")
        for track_id, state in self._tracks.items():
            tcx, tcy = self._center(state.as_tuple())
            dist = ((cx - tcx) ** 2 + (cy - tcy) ** 2) ** 0.5
            if dist < self.max_center_distance_px and dist < best_dist:
                best_dist = dist
                best_id = track_id
        return best_id

    def _smooth(self, prev: SmoothedBBoxState, bbox: tuple[float, float, float, float]) -> SmoothedBBoxState:
        x_min, y_min, x_max, y_max = bbox
        return SmoothedBBoxState(
            x_min=self.alpha * x_min + (1 - self.alpha) * prev.x_min,
            y_min=self.alpha * y_min + (1 - self.alpha) * prev.y_min,
            x_max=self.alpha * x_max + (1 - self.alpha) * prev.x_max,
            y_max=self.alpha * y_max + (1 - self.alpha) * prev.y_max,
        )

    def assign_and_smooth(
        self, detections: List["RawDetectionPayload"]
    ) -> List[tuple["RawDetectionPayload", tuple[float, float, float, float], int]]:
        results: List[tuple["RawDetectionPayload", tuple[float, float, float, float], int]] = []
        for det in detections:
            bbox = det.bbox
            track_id = self._match_track(bbox)
            if track_id is None:
                track_id = self._next_track_id
                self._next_track_id += 1
                state = SmoothedBBoxState(*bbox)
            else:
                state = self._smooth(self._tracks[track_id], bbox)
            self._tracks[track_id] = state
            smoothed_bbox = state.as_tuple()
            # attach track_id for downstream consumers
            det.track_id = track_id
            results.append((det, smoothed_bbox, track_id))
        return results


__all__ = ["BBoxSmoother", "SmoothedBBoxState"]
