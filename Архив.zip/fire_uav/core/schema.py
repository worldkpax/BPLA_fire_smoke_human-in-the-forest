from fire_uav.module_core.schema import *  # noqa: F401,F403

