from fire_uav.module_core.settings_loader import *  # noqa: F401,F403

