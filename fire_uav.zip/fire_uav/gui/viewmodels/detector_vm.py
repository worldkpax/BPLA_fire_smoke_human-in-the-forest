"""
DetectorVM — слой ViewModel для детектора.

• Публикует события APP_START / APP_STOP / CONF_CHANGE через EventBus
• Принимает пачки детекций, пробрасывает их в GUI:
    ─ полный batch   → сигнал detection
    ─ список bbox'ов → сигнал bboxes  (для VideoPane)
"""

from __future__ import annotations

import logging
from typing import Any, Final, List, Tuple

from PyQt6.QtCore import QObject, pyqtSignal

from fire_uav.services.bus import Event, bus

_log: Final = logging.getLogger(__name__)

BBox = Tuple[int, int, int, int]  # x1, y1, x2, y2


class DetectorVM(QObject):
    # -------- публичные сигналы для GUI -------- #
    detection = pyqtSignal(object)  # весь batch
    bboxes = pyqtSignal(list)  # List[BBox] -> VideoPane.overlay

    def __init__(self) -> None:
        super().__init__()
        bus.subscribe(Event.DETECTION, self._on_detection)

    # ------------------- PUBLIC API ------------------- #
    def start(self) -> None:
        """Вызывается кнопкой Start; шлём событие в шину."""
        bus.emit(Event.APP_START)
        _log.debug("APP_START emitted from DetectorVM")

    def stop(self) -> None:
        """Кнопка Stop — останавливаем все ManagedComponent'ы."""
        bus.emit(Event.APP_STOP)
        _log.debug("APP_STOP emitted from DetectorVM")

    def set_conf(self, value: float) -> None:
        """Слайдер меняет порог уверенности YOLO."""
        bus.emit(Event.CONF_CHANGE, value)
        _log.debug("CONF_CHANGE = %.2f", value)

    # ------------------- INTERNAL --------------------- #
    def _on_detection(self, batch: Any) -> None:  # noqa: ANN401
        """Пришёл batch → пробрасываем сигналы наверх."""
        self.detection.emit(batch)

        # извлекаем bbox'ы (d.x1 … d.y2) если такие атрибуты есть
        bxs: List[BBox] = []
        for d in getattr(batch, "detections", []):
            if all(hasattr(d, k) for k in ("x1", "y1", "x2", "y2")):
                bxs.append((int(d.x1), int(d.y1), int(d.x2), int(d.y2)))

        self.bboxes.emit(bxs)
