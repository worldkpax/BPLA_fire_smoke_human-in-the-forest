from __future__ import annotations

import json
import logging
import tempfile
from pathlib import Path
from typing import Final

import folium
from folium.plugins import Draw
from PyQt6.QtCore import QUrl, pyqtSignal, pyqtSlot
from PyQt6.QtWebEngineCore import QWebEnginePage, QWebEngineSettings
from PyQt6.QtWebEngineWidgets import QWebEngineView
from PyQt6.QtWidgets import QFileDialog, QHBoxLayout, QPushButton, QVBoxLayout, QWidget

from fire_uav.gui.utils.gui_toast import show_toast
from fire_uav.gui.viewmodels.planner_vm import PlannerVM

_log: Final = logging.getLogger(__name__)


# ------------------------------------------------------------------ #
#               Custom page to forward console messages
# ------------------------------------------------------------------ #
class _Page(QWebEnginePage):
    consoleMessage = pyqtSignal(int, str, int, str)  # level, msg, line, source

    # type: ignore[override]
    def javaScriptConsoleMessage(self, level, msg, line, source):
        self.consoleMessage.emit(level, msg, line, source)


# ------------------------------------------------------------------ #
#                          PlanWidget
# ------------------------------------------------------------------ #
class PlanWidget(QWidget):
    """Карта с полилинией и трёхкнопочным интерфейсом."""

    def __init__(self, vm: PlannerVM) -> None:
        super().__init__()
        self._vm = vm
        self._tmp_html = Path(tempfile.gettempdir()) / "plan_map.html"

        # -------- top bar -------------------------------------------------
        self._btn_gen = QPushButton("Generate Path")
        self._btn_save = QPushButton("Save Plan")
        self._btn_imp = QPushButton("Import GeoJSON")

        top = QHBoxLayout()
        top.addWidget(self._btn_gen)
        top.addWidget(self._btn_save)
        top.addWidget(self._btn_imp)
        top.addStretch()

        # -------- map view -----------------------------------------------
        self._view = QWebEngineView()
        self._page = _Page(self._view)  # <-- custom page
        self._view.setPage(self._page)
        self._view.settings().setAttribute(
            QWebEngineSettings.WebAttribute.LocalContentCanAccessRemoteUrls, True
        )

        lay = QVBoxLayout(self)
        lay.addLayout(top)
        lay.addWidget(self._view)

        # -------- signals -------------------------------------------------
        self._btn_gen.clicked.connect(self._on_generate)
        self._btn_save.clicked.connect(self._on_save)
        self._btn_imp.clicked.connect(self._on_import)

        self._page.consoleMessage.connect(self._js_bridge)
        self._view.loadFinished.connect(self._after_load)

        self._render_map()

    # -------------------------------------------------------------- #
    #                       MAP RENDERING
    # -------------------------------------------------------------- #
    def _render_map(self) -> None:
        path = self._vm.get_path()
        center = path[0] if path else (55.75, 37.61)  # default Moscow

        fmap = folium.Map(center, zoom_start=14, control_scale=True)

        # только Polyline
        Draw(
            export=False,
            draw_options={
                "polyline": {"shapeOptions": {"color": "#3388ff"}},
                "polygon": False,
                "rectangle": False,
                "circle": False,
                "circlemarker": False,
                "marker": False,
            },
            edit_options={"edit": True, "remove": True},
        ).add_to(fmap)

        if path:
            folium.PolyLine(path, color="red", weight=4).add_to(fmap)

        fmap.save(self._tmp_html)
        self._view.setUrl(QUrl.fromLocalFile(str(self._tmp_html)))

    # -------------------------------------------------------------- #
    #                         JS → Python
    # -------------------------------------------------------------- #
    @pyqtSlot(int, str, int, str)
    def _js_bridge(self, level, message, line, source) -> None:  # noqa: ANN001
        if message.startswith("PY_PATH "):
            gj = json.loads(message.split(" ", 1)[1])
            pts = [(lat, lon) for lon, lat in gj["coordinates"]]
            self._vm.save_plan(pts)
            self._render_map()

    def _after_load(self, ok: bool) -> None:
        if not ok:
            _log.error("Map load failed")
            return

        js = """\
(() => {
  if (!window.L) { console.error('Leaflet failed to load'); return; }
  const map = Object.values(window).find(v => v instanceof L.Map);
  if (!map) { console.error('Map instance not found'); return; }

  function send(gj) { console.log('PY_PATH ' + JSON.stringify(gj)); }

  map.on(L.Draw.Event.CREATED, e => {
      if (e.layerType === 'polyline')
          send(e.layer.toGeoJSON().geometry);
  });

  map.on(L.Draw.Event.EDITED, e => {
      e.layers.eachLayer(l => {
          if (l instanceof L.Polyline)
              send(l.toGeoJSON().geometry);
      });
  });

  map.on(L.Draw.Event.DELETED, () => {
      send({type:'LineString', coordinates:[]});
  });
})();"""
        self._view.page().runJavaScript(js)

    # -------------------------------------------------------------- #
    #                      BUTTON HANDLERS
    # -------------------------------------------------------------- #
    def _on_generate(self) -> None:
        try:
            self._vm.generate_path()
            show_toast(self, "Path ready")
        except Exception as exc:  # noqa: BLE001
            show_toast(self, str(exc))

    def _on_save(self) -> None:
        try:
            fn = self._vm.export_qgc_plan(
                alt_m=120.0
            )  # 120 м фиксировано; измените при необходимости
            show_toast(self, f"Mission saved → {fn.relative_to(fn.parents[1])}")
        except Exception as exc:  # noqa: BLE001
            show_toast(self, str(exc))

    def _on_import(self) -> None:
        fn, _ = QFileDialog.getOpenFileName(
            self, "Import GeoJSON", filter="GeoJSON (*.geojson *.json)"
        )
        if not fn:
            return
        try:
            self._vm.import_geojson(Path(fn))
            self._render_map()
            show_toast(self, "Polyline imported")
        except Exception as exc:  # noqa: BLE001
            show_toast(self, f"Error: {exc}")
