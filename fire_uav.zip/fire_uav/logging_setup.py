"""
Единая точка включения логов.
Читаем YAML-конфиг `fire_uav/config/logging.yaml`,
правим путь до artifacts/logs/fire_uav_debug.log,
добавляем каталог, и запускаем dictConfig.
"""

from __future__ import annotations

import logging.config
from pathlib import Path

import yaml


def setup_logging() -> None:
    # ── 0. где лежит YAML ------------------------------------------------
    cfg_file = (
        # …/fire_uav/logging_setup.py  # …/fire_uav/
        Path(__file__).resolve().parent
        / "config"
        / "logging.yaml"
    )

    # ── 1. читаем конфиг --------------------------------------------------
    with cfg_file.open(encoding="utf-8") as f:
        cfg = yaml.safe_load(f)

    # ── 2. готовим каталог для логов -------------------------------------
    root_dir = Path(__file__).resolve().parents[1]  # <корень проекта>
    log_dir = root_dir / "data" / "artifacts" / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)

    # ── 3. подменяем путь у file-handler’а -------------------------------
    handler = cfg["handlers"].get("debug-file")
    if handler:  # если в YAML такой handler есть
        handler["filename"] = str(log_dir / "fire_uav_debug.log")

    # ── 4. активируем конфигурацию ---------------------------------------
    logging.config.dictConfig(cfg)
