from __future__ import annotations

from queue import Queue

import cv2
from PyQt6.QtWidgets import QApplication

import fire_uav.infrastructure.providers as deps
from fire_uav.gui.utils.gui_toast import show_toast
from fire_uav.services.bus import Event, bus
from fire_uav.services.components.camera import CameraThread
from fire_uav.services.components.detect import DetectThread
from fire_uav.services.lifecycle.manager import LifecycleManager


def _camera_available(index: int | str = 0) -> bool:
    cap = cv2.VideoCapture(index)
    ok = cap.isOpened()
    cap.release()
    return ok


def init_core(*, fps: int = 30) -> None:
    if deps.lifecycle_manager is not None:
        return

    deps.frame_queue = Queue(maxsize=5)
    deps.dets_queue = Queue(maxsize=5)

    if _camera_available():
        deps.camera_factory = lambda: CameraThread(
            index=0,
            fps=fps,
            out_queue=deps.frame_queue,
        )
        deps.detect_factory = lambda: DetectThread(
            in_q=deps.frame_queue,
            out_q=deps.dets_queue,
        )
    else:
        deps.camera_factory = None
        deps.detect_factory = None

        # если GUI уже создан — показываем всплывашку
        if QApplication.instance():
            show_toast(None, "⚠ Камера не найдена — видео поток не будет запущен")

    deps.lifecycle_manager = LifecycleManager()
    bus.subscribe(Event.APP_START, lambda *_: deps.get_lifecycle().start_all())
    bus.subscribe(Event.APP_STOP, lambda *_: deps.get_lifecycle().stop_all())
