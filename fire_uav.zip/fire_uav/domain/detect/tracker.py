from __future__ import annotations
from typing import Dict, Final, Tuple
import numpy as np
from numpy.typing import NDArray

BBox = NDArray[np.float32]  # (x1, y1, x2, y2)
Track = Dict[str, BBox]
TrackId = int
BBox = Tuple[int, int, int, int]

class Tracker:
    _INIT_ID: Final[int] = 0

    def __init__(self) -> None:
        self._next_id: TrackId = self._INIT_ID

    # ------------------------------------------------------------------ #
    def update(self, detections: list[BBox]) -> dict[TrackId, BBox]:
        tracks: dict[TrackId, BBox] = {}
        for det in detections:
            tracks[self._next_id] = det
            self._next_id += 1
        return tracks
